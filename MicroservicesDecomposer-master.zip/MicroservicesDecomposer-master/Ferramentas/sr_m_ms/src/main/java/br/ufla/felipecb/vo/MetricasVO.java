package br.ufla.felipecb.vo;

public class MetricasVO {
	
	public MetricasVO() { }
	
	Double cbo;
	Double rfc;
	Double lcom4;
	
	public Double getCbo() {
		return cbo;
	}
	public void setCbo(Double cbo) {
		this.cbo = cbo;
	}
	public Double getRfc() {
		return rfc;
	}
	public void setRfc(Double rfc) {
		this.rfc = rfc;
	}
	public Double getLcom4() {
		return lcom4;
	}
	public void setLcom4(Double lcom4) {
		this.lcom4 = lcom4;
	}
	
	
}
